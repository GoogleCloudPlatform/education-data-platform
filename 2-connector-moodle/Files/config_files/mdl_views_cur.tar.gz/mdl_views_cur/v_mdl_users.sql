with users as 
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_user 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_user))
,role_assignments as 
	(select distinct userid, roleid 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_role_assignments 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_role_assignments))
,role as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_role 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_role))
,cohort_members as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_cohort_members 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_cohort_members))
,cohort as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_cohort 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_cohort))
select 
	   mu.id as userid ,
	   mu.username, 
	   mu.firstname ,
	   mu.lastname ,
	   mu.email,
	   TIMESTAMP_SECONDS(cast(mu.lastaccess as bigint)) as last_user_access ,
	   mr.shortname as role_name,
	   mc2.name as cohort_name,
	   mu.city,
	   mu.country
from users mu 
  left join role_assignments mra 
  on mra.userid = mu.id 
  left join role mr 
  on mra.roleid = mr.id   
  left join cohort_members mcm 
  on mcm.userid = mu.id
  left join cohort mc2 
  on mcm.cohortid = mc2.id