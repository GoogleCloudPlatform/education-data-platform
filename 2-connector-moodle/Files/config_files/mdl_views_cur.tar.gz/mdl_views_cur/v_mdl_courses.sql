with course as
    (select * 
     from [prj_id_lnd].[dts_nm_lnd].mdl_course 
     where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_course))
, course_categories as
    (select * 
     from [prj_id_lnd].[dts_nm_lnd].mdl_course_categories 
     where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_course_categories))
select mc.id,
       mc.fullname as course_fullname, 
       mc.shortname as course_shortname, 
       mcc.name as category_name,
       mc.summary,
       mc.format,
       mc.theme,
       TIMESTAMP_SECONDS(cast(mc.startdate as bigint)) course_startdate,
       TIMESTAMP_SECONDS(cast(mc.enddate as bigint)) course_enddate,
       EXTRACT(YEAR FROM TIMESTAMP_SECONDS(cast(mc.startdate as bigint))) as year
from course mc 
  inner join course_categories mcc 
  on mc.category = mcc.id