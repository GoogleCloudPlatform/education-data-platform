with enrol as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_enrol 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_enrol))
, user_enrolments as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_user_enrolments 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_user_enrolments))
, user_lastaccess as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_user_lastaccess 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_user_lastaccess))
, grade_grades as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_grade_grades 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_grade_grades))
, grade_items as
	(select * 
	 from [prj_id_lnd].[dts_nm_lnd].mdl_grade_items 
	 where _PARTITIONTIME = (select max(_PARTITIONTIME) from [prj_id_lnd].[dts_nm_lnd].mdl_grade_items))
select me.courseid,
       mue.userid ,
	   /*course enrolment data*/
	   mue.status as status_user_enrollment, 
		 TIMESTAMP_SECONDS(cast(mue.timestart as bigint)) as user_enrol_start,
		 TIMESTAMP_SECONDS(cast(mue.timeend as bigint)) as user_enrol_end,
		 EXTRACT(YEAR FROM TIMESTAMP_SECONDS(cast(mue.timestart as bigint))) as user_enrol_year,
	   me.enrol,
	   me.status as status_enrol,
	   mul.timeaccess,
	   TIMESTAMP_SECONDS(cast(mul.timeaccess as bigint)) as last_access ,
	   /*grade data*/
	   mgi.itemtype,
	   mgg.finalgrade,
	   TIMESTAMP_SECONDS(cast(mgg.timemodified as bigint)) as grade_timemodified,
	   mgg.aggregationstatus,
	   mgg.aggregationweight 
from enrol me 
  inner join user_enrolments mue 
  on me.id = mue.enrolid 
  left join user_lastaccess mul /* um user pode acessar um curso sem enrolment */
  on me.courseid = mul.courseid 
  and mue.userid = mul.userid
  join grade_grades mgg
  on mue.userid = mgg.userid
  join grade_items mgi 
  on mgg.itemid = mgi.id
  and mgi.courseid = me.courseid
